		This font for PERSONAL USE ONLY.
	
		===================================================
		Get the FULL VERSION and COMMERCIAL LICENSE here:
		https://www.creativefabrica.com/product/regina-script/
		
		My Shop : 
		
		https://graphicriver.net/user/jimtypestudio 
		or
		https://www.creativefabrica.com/designer/jimtypestudio/
		
		================
		
		Portofolio :
		
		https://dribbble.com/jimtypestudio
		or
		https://www.behance.net/jimtypestudio
		
		================

		Paypal account for donation or support me : https://paypal.me/jimtypestudio

		===================================================

		NOTE:
		- If there is a problem, question, or anything about my fonts, please sent an email to: jimtypestudio@gmail.com

		- Available for Extended License. Contact us by email : jimtypestudio@gmail.com

		- Share your work with this font and tag us on instagram @jimtypestudio

		================

		Thanks so much,

		Jimtype Studio

